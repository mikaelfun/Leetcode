1. TreeTraversal.py
To run this file, just run it and enter a number of nodes(numbers) to create a tree(BST)
Then enter empty string to start printing

2. PrintFileAndDirectory.py
To run this file, use command line parameter to pass in directory to print.
Or it defaults to printing current working directory

3. MSFS.py
includes dependency on filelock, use pip install filelock before processing
To run, use your own test scripts and import this module or run the process1.py, process2.py, process3.py to test
individually to test simultaneous reading and writing of differnt processes


